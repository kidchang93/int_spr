package org.zerock.springex.sample;


public interface SampleDAO {
}
